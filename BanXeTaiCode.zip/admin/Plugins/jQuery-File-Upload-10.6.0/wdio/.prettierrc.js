'use strict'

module.exports = {
  proseWrap: 'always',
  semi: false,
  singleQuote: true
}
